package com.example.desafioandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ListaItens : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_itens)
    }
}