package com.example.desafioandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NovoUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_novo_usuario)
    }
}